Endless slasher with hordes of enemies and ultimate Boss.
Try to survive as long as possible.

Game was created during 1 week, from the beginning to the end, with no practice in monogame.

Eye is watching you... 

#Controll :exclamation:
  - A/D or <-/-> to move left and right.
  - W/^ to jump
  - E and Q to attack (Also attack in the air)
  - SPACE to use Ultimate

# Version :date:
 *Beta 1.0.1*

# Author
@GoodforGod

# GitHub 
https://github.com/GoodforGod/CorridorGravity